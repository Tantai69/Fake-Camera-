package com.fakecamera.pocox3pro;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 1001;
    private ImageView image;
    private TextView timeText;
    private TextView emptyText;
    private Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);

        image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setVisibility(View.GONE);
        root.addView(image, new FrameLayout.LayoutParams(-1, -1));

        emptyText = new TextView(this);
        emptyText.setText("FAKE CAMERA\n\nChọn ảnh để bắt đầu");
        emptyText.setTextSize(22f);
        emptyText.setTextColor(0xFFFFFFFF);
        emptyText.setGravity(Gravity.CENTER);
        root.addView(emptyText, new FrameLayout.LayoutParams(-1, -1));

        timeText = new TextView(this);
        timeText.setTextSize(18f);
        timeText.setTextColor(0xFFFFFFFF);
        timeText.setPadding(24, 20, 24, 20);
        timeText.setBackgroundColor(0x55000000);
        FrameLayout.LayoutParams timeParams = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        timeParams.topMargin = 25;
        root.addView(timeText, timeParams);

        Button choose = new Button(this);
        choose.setText("CHỌN ẢNH");
        choose.setOnClickListener(v -> openPicker());
        FrameLayout.LayoutParams chooseParams = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START);
        chooseParams.setMargins(24, 0, 0, 35);
        root.addView(choose, chooseParams);

        Button save = new Button(this);
        save.setText("LƯU ẢNH");
        save.setOnClickListener(v -> saveImage());
        FrameLayout.LayoutParams saveParams = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        saveParams.setMargins(0, 0, 24, 35);
        root.addView(save, saveParams);

        setContentView(root);
        updateClock();
    }

    private void openPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_IMAGE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            bitmap = BitmapFactory.decodeStream(in);
            if (bitmap == null) throw new Exception("bitmap null");
            image.setImageBitmap(bitmap);
            image.setVisibility(View.VISIBLE);
            emptyText.setVisibility(View.GONE);
        } catch (Exception e) {
            Toast.makeText(this, "Không đọc được ảnh", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateClock() {
        timeText.setText(new SimpleDateFormat("dd/MM/yyyy  HH:mm:ss", Locale.getDefault()).format(new Date()));
        timeText.postDelayed(this::updateClock, 1000);
    }

    private void saveImage() {
        if (bitmap == null) {
            Toast.makeText(this, "Hãy chọn ảnh trước", Toast.LENGTH_SHORT).show();
            return;
        }
        String name = "FakeCamera_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".jpg";
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        if (Build.VERSION.SDK_INT >= 29) {
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/FakeCamera");
        }
        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) {
            Toast.makeText(this, "Không thể lưu ảnh", Toast.LENGTH_SHORT).show();
            return;
        }
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null || !bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)) throw new Exception("save failed");
            Toast.makeText(this, "Đã lưu vào Pictures/FakeCamera", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            getContentResolver().delete(uri, null, null);
            Toast.makeText(this, "Không thể lưu ảnh", Toast.LENGTH_SHORT).show();
        }
    }
}
