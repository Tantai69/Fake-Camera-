FAKE CAMERA - POCO X3 PRO
Bản build tối giản, không dùng AndroidX/AppCompat để giảm lỗi dependency trên GitHub Actions.
Application ID: com.fakecamera.pocox3pro
Min SDK: 26
Target SDK: 35
