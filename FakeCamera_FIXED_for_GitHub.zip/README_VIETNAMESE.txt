FAKE CAMERA - POCO X3 PRO
===========================

Phiên bản 1.0:
- Không yêu cầu root.
- Chọn ảnh từ bộ nhớ.
- Hiển thị ảnh toàn màn hình theo kiểu camera.
- Hiển thị ngày/giờ.
- Lưu ảnh vào Pictures/FakeCamera.

LƯU Ý:
Đây là app camera giả độc lập. Nó KHÔNG thay thế camera hệ thống và
không làm cho Zalo/Messenger/app khác nhận ảnh giả như camera hệ thống.

CÁCH XUẤT APK:
1. Mở thư mục này bằng Android Studio trên máy tính.
2. Chờ Gradle tải dependency.
3. Chọn Build > Build APK(s).
4. APK debug sẽ nằm trong app/build/outputs/apk/debug/.

Application ID: com.fakecamera.pocox3pro
Min SDK: 26
Target SDK: 35
