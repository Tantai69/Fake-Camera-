package com.fakecamera.pocox3pro

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var image: ImageView
    private lateinit var timeText: TextView
    private lateinit var emptyText: TextView
    private var bitmap: Bitmap? = null

    private val pickImage = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        try {
            bitmap = if (Build.VERSION.SDK_INT >= 28) {
                ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri))
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Images.Media.getBitmap(contentResolver, uri)
            }
            image.setImageBitmap(bitmap)
            image.visibility = View.VISIBLE
            emptyText.visibility = View.GONE
        } catch (e: Exception) {
            Toast.makeText(this, "Không đọc được ảnh", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this).apply {
            setBackgroundColor(0xFF000000.toInt())
        }

        image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            visibility = View.GONE
        }
        root.addView(image, FrameLayout.LayoutParams(-1, -1))

        emptyText = TextView(this).apply {
            text = "FAKE CAMERA\n\nChọn ảnh để bắt đầu"
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(emptyText, FrameLayout.LayoutParams(-1, -1))

        timeText = TextView(this).apply {
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(24, 20, 24, 20)
            setBackgroundColor(0x55000000)
        }
        val timeParams = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START)
        timeParams.topMargin = 25
        root.addView(timeText, timeParams)

        val choose = Button(this).apply {
            text = "CHỌN ẢNH"
            setOnClickListener { pickImage.launch("image/*") }
        }
        val chooseParams = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START)
        chooseParams.setMargins(24, 0, 0, 35)
        root.addView(choose, chooseParams)

        val save = Button(this).apply {
            text = "LƯU ẢNH"
            setOnClickListener { saveImage() }
        }
        val saveParams = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END)
        saveParams.setMargins(0, 0, 24, 35)
        root.addView(save, saveParams)

        setContentView(root)
        updateClock()
    }

    private fun updateClock() {
        timeText.text = SimpleDateFormat("dd/MM/yyyy  HH:mm:ss", Locale.getDefault()).format(Date())
        timeText.postDelayed({ updateClock() }, 1000)
    }

    private fun saveImage() {
        val b = bitmap ?: run {
            Toast.makeText(this, "Hãy chọn ảnh trước", Toast.LENGTH_SHORT).show()
            return
        }
        val name = "FakeCamera_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29)
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/FakeCamera")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { out ->
                b.compress(Bitmap.CompressFormat.JPEG, 95, out)
            }
            Toast.makeText(this, "Đã lưu vào Pictures/FakeCamera", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Không thể lưu ảnh", Toast.LENGTH_SHORT).show()
        }
    }
}
